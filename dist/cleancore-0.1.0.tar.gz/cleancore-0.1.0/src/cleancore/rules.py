RULES = {
    "GDPR_COMPLIANT_IMPUTATION_v2": {
        "description": "Fill missing values using median",
        "owner": "Data Protection Office"
    },
    "FINANCE_RULE_001": {
        "description": "Constant salary requires HR approval",
        "owner": "Finance Department"
    }
}
